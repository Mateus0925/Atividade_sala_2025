let number = parseFloat(prompt("Digite um número:"));

for (let i = 1; 1 <= number; i++) {
    alert(number);
    number--;
}
